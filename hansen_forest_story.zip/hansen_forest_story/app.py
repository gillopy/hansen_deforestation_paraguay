import json
import os
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_file
import ee

BASE_DIR = Path(__file__).resolve().parent
GEOJSON_PATH = Path(os.getenv("GEOJSON_PATH", BASE_DIR / "data" / "py.json"))
EE_PROJECT = os.getenv("EE_PROJECT", "hansen-480517")
DATASET_ID = "UMD/hansen/global_forest_change_2025_v1_13"

app = Flask(__name__)

dataset = None
geojson_data = None


def init_earth_engine():
    global dataset
    try:
        # Recommended for local development after running:
        # earthengine authenticate
        ee.Initialize(project=EE_PROJECT)
    except Exception as exc:
        raise RuntimeError(
            "No fue posible inicializar Google Earth Engine. "
            "Ejecuta 'earthengine authenticate' en desarrollo local o "
            "configura credenciales de servidor para producción."
        ) from exc
    dataset = ee.Image(DATASET_ID)


def load_geojson():
    global geojson_data
    if not GEOJSON_PATH.exists():
        raise FileNotFoundError(
            f"No existe el GeoJSON: {GEOJSON_PATH}. "
            "Copia tu py.json en data/py.json o define GEOJSON_PATH."
        )
    with GEOJSON_PATH.open(encoding="utf-8") as f:
        geojson_data = json.load(f)


def features():
    if geojson_data["type"] == "FeatureCollection":
        return geojson_data["features"]
    if geojson_data["type"] == "Feature":
        return [geojson_data]
    return [{
        "type": "Feature",
        "properties": {"name": "ROI"},
        "geometry": geojson_data,
    }]


def department_names():
    result = []
    for feature in features():
        name = feature.get("properties", {}).get("name")
        if name:
            result.append(name)
    return sorted(set(result))


def get_feature(name):
    for feature in features():
        if feature.get("properties", {}).get("name") == name:
            return feature
    return None


def ee_geometry(feature):
    return ee.Geometry(feature["geometry"])


def loss_mask(roi, year_min, year_max):
    clipped = dataset.clip(roi)
    loss_year = clipped.select("lossyear")
    loss = clipped.select("loss")
    return loss_year.updateMask(
        loss_year.gte(year_min)
        .And(loss_year.lte(year_max))
        .And(loss)
    )


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/departments")
def departments():
    return jsonify({"departments": department_names()})


@app.route("/api/department/<path:name>")
def department(name):
    feature = get_feature(name)
    if not feature:
        return jsonify({"error": "Departamento no encontrado"}), 404
    return jsonify(feature)


@app.route("/api/map")
def map_layer():
    if dataset is None:
        return jsonify({"error": "Earth Engine no está inicializado"}), 503

    name = request.args.get("department")
    layer = request.args.get("layer", "loss")
    year_min = int(request.args.get("year_min", 0))
    year_max = int(request.args.get("year_max", 25))

    feature = get_feature(name) if name else None
    if not feature:
        return jsonify({"error": "Departamento no encontrado"}), 404

    roi = ee_geometry(feature)

    if layer == "cover":
        image = dataset.select("treecover2000").clip(roi)
        vis = {"min": 0, "max": 100, "palette": ["000000", "0b5d1e"]}
    elif layer == "gain":
        image = dataset.select("gain").selfMask().clip(roi)
        vis = {"palette": ["1d4ed8"]}
    else:
        image = loss_mask(roi, year_min, year_max)
        vis = {"min": year_min, "max": year_max, "palette": ["ffff00", "ff0000"]}

    map_id = image.getMapId(vis)
    return jsonify({
        "mapid": map_id["mapid"],
        "token": map_id["token"],
        "tile_url": map_id["tile_fetcher"].url_format,
    })


@app.route("/api/download")
def download():
    if dataset is None:
        return jsonify({"error": "Earth Engine no está inicializado"}), 503

    name = request.args.get("department")
    layer = request.args.get("layer", "combined")
    year_min = int(request.args.get("year_min", 0))
    year_max = int(request.args.get("year_max", 25))
    dimensions = min(max(int(request.args.get("dimensions", 2200)), 500), 4000)

    feature = get_feature(name) if name else None
    if not feature:
        return jsonify({"error": "Departamento no encontrado"}), 404

    roi = ee_geometry(feature)
    clipped = dataset.clip(roi)

    cover = clipped.visualize(
        bands=["treecover2000"], min=0, max=100,
        palette=["000000", "0b5d1e"]
    )

    loss = loss_mask(roi, year_min, year_max).visualize(
        min=year_min, max=year_max,
        palette=["ffff00", "ff0000"]
    )

    gain = clipped.select("gain").selfMask().visualize(
        palette=["1d4ed8"]
    )

    if layer == "cover":
        image = cover
        suffix = "tree_cover"
    elif layer == "loss":
        image = loss
        suffix = f"tree_loss_{year_min}_{year_max}"
    elif layer == "gain":
        image = gain
        suffix = "tree_gain"
    else:
        image = cover.blend(loss).blend(gain)
        suffix = f"combined_{year_min}_{year_max}"

    # getThumbURL is synchronous from the server's perspective: EE returns
    # a signed URL that Flask streams back to the browser.
    url = image.getThumbURL({
        "region": roi,
        "dimensions": dimensions,
        "format": "png",
    })

    import urllib.request
    safe_name = name.replace(" ", "_").replace("/", "-")
    tmp = BASE_DIR / f".tmp_{safe_name}_{suffix}.png"
    urllib.request.urlretrieve(url, tmp)

    response = send_file(
        tmp,
        mimetype="image/png",
        as_attachment=True,
        download_name=f"{safe_name}_{suffix}.png",
    )

    @response.call_on_close
    def cleanup():
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass

    return response


@app.route("/health")
def health():
    return jsonify({"status": "ok", "earth_engine": dataset is not None})


if __name__ == "__main__":
    load_geojson()
    init_earth_engine()
    app.run(host="127.0.0.1", port=5000, debug=True)
