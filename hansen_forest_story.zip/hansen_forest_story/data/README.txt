Coloca aquí el archivo GeoJSON de departamentos utilizado por el notebook original.

Nombre esperado:
    py.json

Cada Feature debería tener:
    properties.name

Ejemplo conceptual:
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {"name": "Alto Paraguay"},
      "geometry": {...}
    }
  ]
}
