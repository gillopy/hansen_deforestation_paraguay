# Hansen Forest Story — Paraguay

Aplicación web interactiva que transforma el flujo del notebook de Hansen Global
Forest Change en una pieza de periodismo de datos con:

- Google Earth Engine como motor geoespacial.
- Flask como backend Python.
- Leaflet para el mapa.
- D3.js + Scrollama para el scrollytelling.
- GeoJSON para delimitar departamentos.
- Descarga de mapas PNG desde Earth Engine.

## 1. Archivos

Copia tu GeoJSON original como:

    data/py.json

Debe contener propiedades `name` en cada Feature, porque el código utiliza ese
campo para identificar los departamentos.

## 2. Instalar

Python 3.10+ recomendado.

    python -m venv .venv
    .venv\Scripts\activate

En Linux/macOS:

    source .venv/bin/activate

Luego:

    pip install -r requirements.txt

## 3. Autenticar Earth Engine

Para desarrollo local:

    earthengine authenticate

Después verifica que el proyecto utilizado tenga Earth Engine habilitado.

El código inicializa:

    ee.Initialize(project="hansen-480517")

Puedes cambiarlo mediante:

    set EE_PROJECT=tu-proyecto

En Linux/macOS:

    export EE_PROJECT=tu-proyecto

## 4. Ejecutar

    python app.py

Abrir:

    http://127.0.0.1:5000

## 5. Qué se transformó del notebook

El notebook original utiliza `ipywidgets` para seleccionar departamento,
resolución y rango de años, y `geemap.get_image_thumbnail()` para generar
tres imágenes PNG. En una página web convencional esos widgets no existen:
el navegador ejecuta JavaScript, mientras que el SDK de Earth Engine de Python
debe ejecutarse en el servidor.

Por eso la aplicación separa:

    Navegador
        ↓
    JavaScript / Leaflet / D3 / Scrollama
        ↓ HTTP
    Flask
        ↓
    Earth Engine Python API
        ↓
    Hansen Global Forest Change 2025 v1.13

## 6. Producción

No uses `earthengine authenticate` interactivo en un servidor público.

Usa una cuenta de servicio de Google Cloud con acceso al proyecto Earth Engine
y configura `GOOGLE_APPLICATION_CREDENTIALS` apuntando al JSON de credenciales.

Ejemplo:

    export GOOGLE_APPLICATION_CREDENTIALS=/ruta/service-account.json
    export EE_PROJECT=hansen-480517

Luego:

    gunicorn -w 2 -b 0.0.0.0:8000 app:app

El archivo de credenciales nunca debe incluirse en GitHub.

## 7. Descarga

El botón "Descargar PNG" genera una composición:

    cobertura 2000
        +
    pérdida filtrada por intervalo
        +
    ganancia

y la devuelve como archivo PNG.

La resolución solicitada está limitada a 500–4000 píxeles para evitar
solicitudes excesivamente pesadas.

## 8. Limitaciones

El producto Hansen identifica pérdida de cobertura arbórea según su metodología.
No debe interpretarse automáticamente como causa de deforestación.

Para atribuir causas se recomienda combinarlo con Sentinel-2/Landsat,
cobertura de suelo, incendios, infraestructura, agricultura y otras fuentes.
